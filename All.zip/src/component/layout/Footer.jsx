import React from 'react';

function Footer(props) {
    return (
       <>
       <h1>hello footer</h1>
       </>
    );
}

export default Footer;